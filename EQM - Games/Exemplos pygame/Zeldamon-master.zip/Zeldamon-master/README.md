Zeldamon is a game that draws inspiration from the old-school Game Boy games Pokemon Red and Blue, and Legend of Zelda: Link's Awakening.  My goal is to create a game where you can switch between the pokemon trainer and his pokemon, explore dungeons, and fight other pokemon on the overworld without switching to a battle screen.  As the pokemon you will be able to use attacks and techniques, and as the trainer you will be able to use tools that have similar effects.  You will even be able to fight pokemon as the trainer, but if the trainer loses all of his health your pokemon won't be able to continue without you.

The game itself is still early in development and is currently missing most of its planned features.  

Zeldamon is written for Python 3 and uses the Pygame and NumPy libraries.  The world maps are XML files created with the Tiled Map Editor.

Contact Information:

Name: Brendan Jones

Email: brendan_kaizen@yahoo.com