#Pygame scripts:
* **mouse.py**: Moves the sprite to the position clicked.
* **keyboard.py**: Moves the sprite with keyboard arrows.
* **bounce.py**: Bounces a sprite on window's boundaries.
* **multiple.py**: Create multiple sprites & move them at the same time in the same direction.
* **draw_lines.py**: Draw multiple intersecting lines on the screen.

##Prerequisite:
* python.
* pygame.
