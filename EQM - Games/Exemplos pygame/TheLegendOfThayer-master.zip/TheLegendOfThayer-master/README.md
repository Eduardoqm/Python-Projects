# TheLegendOfThayer
PyGame Implementation of The Legend of Zelda (NES) - West Point Edition

16 boxes Width * 30 pix = 480
11 Boxes Height * 30 pix = 330 (plus 100 pix per side for health and stuffz)
